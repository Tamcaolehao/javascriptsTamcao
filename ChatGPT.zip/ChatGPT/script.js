const button = document.getElementById("button");
button.addEventListener("click", function() {
  alert("Xin chào! Đây là trang web của tôi!");
});
